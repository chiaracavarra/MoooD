/**
 * 
 */
package com.absence.chiara.MoodLed;

import java.awt.Color;
import javax.swing.JColorChooser;
import javax.swing.JFrame;

/**
 * @author chiara@absence.it
 *
 */
public class MoodLed {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		ScreenAnalyzer sa = new ScreenAnalyzer();
		Color c = sa.getPredominantColor();		
		JColorChooser cp = new JColorChooser(c);
		JFrame f = new JFrame();
		
		// TODO
		//JButton b = new JButton("Refresh");
		//b.addActionListener();
		
		f.setSize(300, 300);
		f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		f.getContentPane().add(cp);
		
		cp.setColor(c);
		
		f.pack();
		f.setVisible(true);		
	}
}
