package com.absence.chiara.MoodLed;

import java.awt.Color;
import java.util.Arrays;
import java.util.Collections;

public enum Colors {

	WHITE	(Color.WHITE, 0,  0),
	GRAY	(Color.GRAY, 0,  0),
	BLACK	(Color.BLACK, 0,  0),

//	H_000(Color.GRAY, 0, 10),
	H_010(Color.GRAY, 0, 20),
//	H_020(Color.GRAY, 0, 30),
	H_030(Color.GRAY, 0, 40),
//	H_040(Color.GRAY, 0, 50),
	H_050(Color.GRAY, 0, 60),
//	H_060(Color.GRAY, 0, 70),
	H_070(Color.GRAY, 0, 80),
//	H_080(Color.GRAY, 0, 90),
	H_090(Color.GRAY, 0, 100),
//	H_100(Color.GRAY, 0, 110),
	H_110(Color.GRAY, 0, 120),
//	H_120(Color.GRAY, 0, 130),
	H_130(Color.GRAY, 0, 140),
//	H_140(Color.GRAY, 0, 150),
	H_150(Color.GRAY, 0, 160),
//	H_160(Color.GRAY, 0, 170),
	H_170(Color.GRAY, 0, 180),
//	H_180(Color.GRAY, 0, 190),
	H_190(Color.GRAY, 0, 200),
//	H_200(Color.GRAY, 0, 210),
	H_210(Color.GRAY, 0, 220),
//	H_220(Color.GRAY, 0, 230),
	H_230(Color.GRAY, 0, 240),
//	H_240(Color.GRAY, 0, 250),
	H_250(Color.GRAY, 0, 260),
//	H_260(Color.GRAY, 0, 270),
	H_270(Color.GRAY, 0, 280),
//	H_280(Color.GRAY, 0, 290),
	H_290(Color.GRAY, 0, 300),
//	H_300(Color.GRAY, 0, 310),
	H_310(Color.GRAY, 0, 320),
//	H_320(Color.GRAY, 0, 330),
	H_330(Color.GRAY, 0, 340),
//	H_340(Color.GRAY, 0, 350),
	H_350(Color.GRAY, 0, 360);

	private Color color;
	private Integer count;
	private final int maxHue;

	Colors(Color color, int count, int maxHue) {
		this.color = color;
		this.count = count;
		this.maxHue = maxHue;
	}

	public static void count(Color rgbColor) {

		float h = 0;
		float s = 0;
		float b = 0;
		float[] hsb = {0, 0, 0};

		Color.RGBtoHSB(rgbColor.getRed(), rgbColor.getGreen(), rgbColor.getBlue(), hsb);

		h = (hsb[0]*360);
		s = (hsb[1]*100);
		b = (hsb[2]*100);

		if (b > 98)
			WHITE.count++;
		else if (b < 5)
			BLACK.count++;
		else if (s < 5)
			GRAY.count++;
		else {

			Colors c = Colors.values()[(int) (h / 20 + 3)];
			c.count++;
			c.color = new Color(
					(c.color.getRed() + rgbColor.getRed())/2,
					(c.color.getGreen() + rgbColor.getGreen())/2,
					(c.color.getBlue() + rgbColor.getBlue())/2);
		}
	}

	public static Color getPredominantColor() {

		Color max = Color.WHITE;
		StringBuilder s = new StringBuilder();
		int pixelCount = 0;

		for (Colors c : Colors.values()) {

			pixelCount += c.getCount();
			s.append(String.format("%s\t = %d;\n", c.toString().toLowerCase(), c.getCount()));
		}

		max = Collections.max(Arrays.asList(Colors.values()), new ColorComparator()).color;

		System.out.println(String.format("%s [%s]\nTotal count:\t %d\nExpected:\t 4147200", s.toString(), max.toString(), pixelCount));

		return max;
	}

	public Integer getCount() {
	    return count;
    }
}

